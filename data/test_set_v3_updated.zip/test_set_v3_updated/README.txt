Version 2 test set for yolov3 pytorch project
Set includes five classes (Cat,Car, Dog, Apple, Orange) each class has about 100 images